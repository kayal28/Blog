// 这里数据请求的唯一入口 
import personal from './personal'
import vote from './vote'

export default{
    personal,
    vote
}
