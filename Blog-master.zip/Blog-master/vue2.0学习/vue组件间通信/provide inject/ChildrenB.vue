<template>
  <div class="border1">
    <h2>B 结点</h2>
    <ChildrenD />
    <ChildrenE />
  </div>
</template>
<script>
import ChildrenD from "./ChildrenD";
import ChildrenE from "./ChildrenE";
export default {
  components: {
    ChildrenD,
    ChildrenE
  }
};
</script>
